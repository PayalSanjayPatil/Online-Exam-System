# ONLINE-EXAMINATION
The project should be capable of the following functionalities.  Login  Update Profile and Password  Selecting answers for MCQs  Timer and auto submit  Closing session and Logout
